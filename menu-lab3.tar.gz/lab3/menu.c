/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.c                                 */
/*  PRINCIPAL AUTHOR      :  Lezg                                   */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/20                             */
/*  DESCRIPTION           :  interface of menu                      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Lezg,2014/09/20
 */

/*#include "menu.h"

#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 5

/* menu list */
/*LinkList *menuList;
char *delCmd;
int totalCmd=CMD_NUM;

typedef struct _CmdNode
{
	char* cmd;
	char* desc;
	int   (*handler)();
}CmdNode;

static CmdNode cmds[CMD_NUM]=
{
	{"help","To show more about the function name",NULL},
	{"ls","To show list directory contents",NULL},
	{"cal","To show the calendar",NULL},
	{"date","To show the date",NULL},
	{"man","To show the cmd manual",NULL}
};

int PrintAllCmds(CmdNode *cmdNode)
{
	if(!cmdNode)
	{
		return FAILURE;
	}
	printf("%s\n",cmdNode->cmd);
	return SUCCESS;
}

void ShowLinkList(LinkList *pList)
{
	if(!pList)
	{
		return;
	}
	printf("Cmds Menu List:\n");
	TraverseLinkList(pList,(int(*)(void*))PrintAllCmds);
}

CmdNode *SearchCmd(LinkList * pList,char *cmd)
{
	CmdNode *pNode;
	pNode=(CmdNode *)GetLinkListFirstNode(pList);
	while(pNode!=NULL)
	{
		if(!strcmp(pNode->cmd,cmd))
		{
			return pNode;
		}
		pNode=(CmdNode *)GetLinkListNextNode(pList,pNode);
	}
	return NULL;
}

void AddCmd(char cmd[],char desc[],int(*handler)())
{
	int flag;
	CmdNode *pNode;
	while(1)
	{
		pNode=SearchCmd(menuList,cmd);
		if(pNode!=NULL)
		{
			printf("The menu has the cmd.\n");
			return;
		}
		else
		{
			break;
		}
	}
	flag=LinkList_Insert_tail(menuList,cmd,desc,handler);
	if(flag)
	{
		++totalCmd;
		printf("Successfully adding %s command\n",cmd);
	}
	else
	{
		printf("The %s command to add failure\n",cmd);
	}
}

int DeleteNode(CmdNode *cmdNode)
{
	if(!cmdNode)
	{
		return FAILURE;
	}
	if (!strcmp(cmdNode->cmd,delCmd))
	{
		free(delCmd);
		return SUCCESS;
	}
	return FAILURE;
}

void DeleteCmd(char cmd[])
{
	int index;
	CmdNode *pNode;
	delCmd=cmd;
	while(1)
	{
		index=TraverseLinkList(menuList,(int(*)(void*))DeleteNode);
		if (index!=FAILURE)
		{
			if(LinkList_Delete(menuList,index))
			{
				--totalCmd;
				printf("The %s command is deleted\n",cmd);
			}
			else
			{
				printf("The %s command is no deleted\n",cmd);
			}
			break;
		}
		else
		{
			printf("There is no this command\n");
			return;
		}
	}
}

void InputCmd()
{
	char iCmd[1024];
	char iDelCmd[10];
	CmdNode *pNode;
	while(1)
	{
		printf("please input cmd -> ");
		scanf("%s",iCmd);
		if (!strcmp(iCmd,"help"))
		{
			ShowLinkList(menuList);
		}
		else if(!strcmp(iCmd,"-del"))
		{
			printf("please input the command you want to delete.\n");
			scanf("%s",iDelCmd);
			DeleteCmd(iDelCmd);
		}
		else
		{
			pNode=SearchCmd(menuList,iCmd);
			if (pNode==NULL)
			{
				printf("This is wrong cmd!\n");
			}
			else
			{
				printf("%s : %s\n",pNode->cmd,pNode->desc);
				if(pNode->handler!=NULL)
				{
					pNode->handler();
				}
			}
		}
	}
}

void StartMenu()
{
	int i;
	printf("waiting for starting menu...\n");
	menuList=CreateLinkList(sizeof(CmdNode));
	for (i=0;i<CMD_NUM;++i)
	{
		LinkList_Insert_tail(menuList,cmds[i]);
	}
	printf("The menu is started.Please enjoy.\n\n");
	InputCmd();
}*/