#include "menu.h"

int Help()
{
	printf("This is help cmd.\n");
}

int main()
{
	AddCmd("help","To show more about the function name",Help);
	AddCmd("ls","To show list directory contents",NULL);
	StartMenu();
	return 0;
}