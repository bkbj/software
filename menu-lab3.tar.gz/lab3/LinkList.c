/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  LinkList.c                             */
/*  PRINCIPAL AUTHOR      :  Lezg                                   */
/*  SUBSYSTEM NAME        :  LinkList                               */
/*  MODULE NAME           :  LinkList                               */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/20                             */
/*  DESCRIPTION           :  interface of linkList                  */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Lezg,2014/09/20
 */

#include "LinkList.h"

LinkList *CreateLinkList(int size)
{
	LinkList *list;
	ElemType data=NULL;
	list=(LinkList *)malloc(sizeof(LinkList));
	if(!list)
	{
		return FAILURE;
	}
	list->head=CreateLinkListNode(data);
	if (!list->head)
	{
		free(list);
		return FAILURE;
	}
	list->nodeSize=size;
	list->tail=list->head;
	return list;
}

void DestoryLinkList(LinkList *pList)
{
	ClearLinkList(pList);
	free(pList->head);
	pList->head=NULL;
	free(pList);
	pList=NULL;
}

int LinkList_Insert_head(LinkList *pList,...)
{
	DataNode *ptr;
	void *data;
	void *pos=&pList+1;
	if (!(pList&&pList->head))
	{
		return FAILURE;
	}
	data=(void *)malloc(pList->nodeSize);
	if (!data)
	{
		return FAILURE;
	}
	memcpy(data,pos,pList->nodeSize);
	ptr=CreateLinkListNode(data);
	if (!ptr)
	{
		return FAILURE;
	}
	ptr->next=pList->head->next;
	pList->head->next=ptr;
	return SUCCESS;
}

int LinkList_Insert_index(LinkList *pList,int n,...)
{
	DataNode *ptr;
	DataNode *newptr;
	void *data;
	void *pos=&pList+2;
	ptr=GetAddr(pList,n-1);
	if(!ptr)
	{
		return FAILURE;
	}
	data=(void *)malloc(pList->nodeSize);
	if(!data)
	{
		return FAILURE;
	}
	memcpy(data,pos,pList->nodeSize);
	newptr=CreateLinkListNode(data);
	if(!newptr)
	{
		return FAILURE;
	}
	if(ptr->next==pList->tail)
	{
		pList->tail=newptr;
	}
	newptr->next=ptr->next;
	ptr->next=newptr;
	return SUCCESS;
}

int LinkList_Insert_tail(LinkList *pList,...)
{
	DataNode *ptr;
	void *data;
	void *pos;
	void *descPos;
	void *handler;
	pos=&pList+1;
	descPos=&pList+2;
	handler=&pList+3;
	if(!(pList&&pList->head))
	{
		return FAILURE;
	}
	data=(void *)malloc(pList->nodeSize);
	if(!data)
	{
		return FAILURE;
	}
	memcpy(data,pos,pList->nodeSize);
	ptr=CreateLinkListNode(data);
	if(!ptr)
	{
		return FAILURE;
	}
	pList->tail->next=ptr;
	pList->tail=ptr;
	return SUCCESS;
}

int GetElem(LinkList *pList,int n,void *data)
{
	DataNode *ptr;
	if(!data)
	{
		return FAILURE;
	}
	ptr=GetAddr(pList,n);
	if(!ptr)
	{
		return FAILURE;
	}
	memcpy(data,ptr->data,pList->nodeSize);
	return SUCCESS;
}

int TraverseLinkList(LinkList *pList,int(*f)(ElemType))
{
	int index;
	DataNode *ptr=NULL;
	if(!(pList && pList->head))
	{
		return FAILURE;
	}
	ptr=pList->head->next;
	for (index = 1;ptr;ptr=ptr->next)
	{
		if(!f(ptr->data))
		{
			return (index+1);
		}
		++index;
	}
	return FAILURE;
}

void ClearLinkList(LinkList *pList)
{
	while(LinkList_Delete(pList,1));
}

int LinkList_Delete(LinkList *pList,int n)
{
	DataNode *ptr;
	DataNode *tmp;
	if(!pList->head->next)
	{
		return FAILURE;
	}
	ptr=GetAddr(pList,n-1);
	if(ptr->next==pList->tail)
	{
		pList->tail=ptr;
	}
	if(!(ptr&&ptr->next))
	{
		return FAILURE;
	}
	tmp=ptr->next;
	ptr->next=ptr->next->next;
	free(tmp->data);
	free(tmp);
	return SUCCESS;
}

DataNode *GetAddr(LinkList *pList,int n)
{
	DataNode *ptr;
	int index=0;
	if(n<0)
	{
		return FAILURE;
	}
	ptr=pList->head;
	while(ptr && index<n)
	{
		ptr=ptr->next;
		++index;
	}
	return ptr;
}

DataNode *CreateLinkListNode(ElemType data)
{
	DataNode *node;
	node=(DataNode *)malloc(NODESIZE);
	if(!node)
	{
		return FAILURE;
	}
	node->data=data;
	node->next=NULL;
	return node;
}

ElemType GetLinkListFirstNode(LinkList *pList)
{
	if(!pList)
	{
		return NULL;
	}
	return pList->head->next->data;
}

ElemType GetLinkListNextNode(LinkList *pList,ElemType pNode)
{
	DataNode *pTmpNode;
	if(!pList || !pNode)
	{
		return NULL;
	}
	pTmpNode=pList->head->next;
	while(pTmpNode!=NULL)
	{
		if(pTmpNode->data==pNode)
		{
			if(pTmpNode==pList->tail)
			{
				return NULL;
			}
			return pTmpNode->next->data;
		}
		pTmpNode=pTmpNode->next;
	}
	return NULL;
}
