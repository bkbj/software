#include "menu.h"

void StartMenu()
{
	char cmd[1024];
	printf("start menu...\n");
	while(1)
	{
		printf("please input cmd -> ");
		scanf("%s",cmd);
		printf("%s\n",cmd);
	}
}

void AddCmd(char *cmd,char *desc,int(*handler)())
{
	if (cmd==NULL || desc==NULL)
	{
		printf("please input necessary info.\n");
	}
	else
	{
		printf("Successfully adding %s command\n",cmd);
	}
}

