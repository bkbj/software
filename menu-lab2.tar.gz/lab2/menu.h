/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.h                                 */
/*  PRINCIPAL AUTHOR      :  Lezg                                   */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/20                             */
/*  DESCRIPTION           :  interface of menu                      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Lezg,2014/09/20
 */

#ifndef MENU_H
#define MENU_H

#include "LinkList.h"


/* input cmd */
void InputCmd();

/* start menu */
void StartMenu();

/* add cmd */
void AddCmd(char *cmd,char *desc,int(*handler)());

/* delete command */
void DeleteCmd(char *cmd);

#endif
