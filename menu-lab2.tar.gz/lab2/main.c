#include "menu.h"

int main()
{
	StartMenu();
	InputCmd();
	return 0;
}