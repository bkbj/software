/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  LinkList.h                             */
/*  PRINCIPAL AUTHOR      :  Lezg                                   */
/*  SUBSYSTEM NAME        :  LinkList                               */
/*  MODULE NAME           :  LinkList                               */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/20                             */
/*  DESCRIPTION           :  interface of linkList                  */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Lezg,2014/09/20
 */

#ifndef LINKLIST_H
#define LINKLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FAILURE 0
#define SUCCESS 1
#define NODESIZE sizeof(DataNode)

typedef void* ElemType;

typedef struct _DataNode
{
	ElemType data;
	struct _DataNode *next;
}DataNode;

typedef struct list
{
	DataNode *head;
	DataNode *tail;
	int nodeSize;
}LinkList;

/* create linkList */
LinkList *CreateLinkList(int);

/* destory linkList */
void DestoryLinkList(LinkList *);

/* clear linkList */
void ClearLinkList(LinkList *);

/* insert data into linkList at head of linkList */
int LinkList_Insert_head(LinkList *,...);

/* insert data into linkList at index of linkList */
int LinkList_Insert_index(LinkList *,...);

/* insert data into linkList at tail of linkList */
int LinkList_Insert_tail(LinkList *,...);

/* delete the index node of linkList */
int LinkList_Delete(LinkList *,int);

/* get the index node of linkList */
int GetElem(LinkList *,int,void *);

/* traverse the linkList */
int TraverseLinkList(LinkList *,int(*)(ElemType));

/* get the address of the index node */
DataNode *GetAddr(LinkList *,int);

/* create a node of linkList */
DataNode *CreateLinkListNode(ElemType);

/* get the first node of linkList */
ElemType GetLinkListFirstNode(LinkList *);

/* get next node */
ElemType GetLinkListNextNode(LinkList *,ElemType);

#endif